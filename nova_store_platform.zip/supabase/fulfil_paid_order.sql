create or replace function public.fulfil_paid_nova_order(p_order_id uuid,p_payment_id text) returns void language plpgsql security definer set search_path=public as $$
declare o public.orders%rowtype; it record;
begin
select * into o from public.orders where id=p_order_id for update;
if not found then raise exception 'Order not found'; end if;
if o.status in('paid','processing','shipped','delivered') then return; end if;
if o.status<>'pending_payment' then raise exception 'Order is not pending payment'; end if;
for it in select product_id,quantity from public.order_items where order_id=p_order_id loop
if it.product_id is null then raise exception 'Product missing'; end if;
update public.products set stock=stock-it.quantity where id=it.product_id and active=true and stock>=it.quantity;
if not found then raise exception 'Insufficient stock'; end if;
end loop;
update public.orders set status='paid',paid_at=now(),payfast_payment_id=nullif(p_payment_id,'') where id=p_order_id;
end; $$;
revoke all on function public.fulfil_paid_nova_order(uuid,text) from public,anon,authenticated;
grant execute on function public.fulfil_paid_nova_order(uuid,text) to service_role;
