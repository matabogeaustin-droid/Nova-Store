create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,email text,role text not null default 'customer' check(role in('customer','admin')),created_at timestamptz default now());
create table if not exists public.products(id uuid primary key default gen_random_uuid(),name text not null,category text not null check(category in('Clothing','Shoes','Bags','Accessories')),description text default '',price numeric(10,2) not null check(price>0),stock integer not null default 0 check(stock>=0),image_url text not null,active boolean default true,created_at timestamptz default now());
create table if not exists public.orders(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),status text not null default 'pending_payment' check(status in('pending_payment','paid','processing','shipped','delivered','cancelled','payment_failed')),total_zar numeric(10,2) not null check(total_zar>0),currency text default 'ZAR',customer_name text not null,customer_phone text not null,delivery_address text not null,delivery_city text not null,delivery_postal_code text default '',customer_notes text default '',payfast_payment_id text,paid_at timestamptz,created_at timestamptz default now());
create table if not exists public.order_items(id uuid primary key default gen_random_uuid(),order_id uuid not null references public.orders(id) on delete cascade,product_id uuid references public.products(id) on delete set null,product_name text not null,unit_price numeric(10,2) not null,quantity integer not null check(quantity>0),line_total numeric(10,2) not null);
create or replace function public.is_store_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
alter table public.profiles enable row level security;alter table public.products enable row level security;alter table public.orders enable row level security;alter table public.order_items enable row level security;
create policy "profile own or admin" on public.profiles for select to authenticated using(id=auth.uid() or public.is_store_admin());
create policy "public active products" on public.products for select to anon,authenticated using(active=true or public.is_store_admin());
create policy "admin add products" on public.products for insert to authenticated with check(public.is_store_admin());
create policy "admin edit products" on public.products for update to authenticated using(public.is_store_admin()) with check(public.is_store_admin());
create policy "admin delete products" on public.products for delete to authenticated using(public.is_store_admin());
create policy "owner or admin orders" on public.orders for select to authenticated using(user_id=auth.uid() or public.is_store_admin());
create policy "admin update orders" on public.orders for update to authenticated using(public.is_store_admin()) with check(public.is_store_admin());
create policy "owner or admin order items" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and (o.user_id=auth.uid() or public.is_store_admin())));
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,email,role) values(new.id,new.email,'customer') on conflict(id) do nothing;return new;end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
insert into public.products(name,category,description,price,stock,image_url) values
('Classic Oversized Tee','Clothing','Example product — replace with real stock details.',249,10,'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=80'),
('Everyday Hoodie','Clothing','Example product — replace with real stock details.',499,10,'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=700&q=80'),
('Relaxed Jeans','Clothing','Example product — replace with real stock details.',399,10,'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=700&q=80'),
('Classic Sneakers','Shoes','Example product — replace with real stock details.',699,10,'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80'),
('Everyday Tote','Bags','Example product — replace with real stock details.',299,10,'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=700&q=80'),
('Minimal Watch','Accessories','Example product — replace with real stock details.',349,10,'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80');
-- After creating the owner's account, guardian runs:
-- update public.profiles set role='admin' where email='YOUR-OWNER-EMAIL';
