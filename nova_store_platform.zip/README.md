# Nova Store: website + installable Android PWA

This package contains a mobile-friendly storefront, customer login, cart, product admin panel, orders table, Supabase database schema and PayFast server-side checkout functions.

## Honest status
This is a deployable starter, **not yet a live store**. I cannot create your hosting/payment accounts or activate payments without the account owner completing setup. Until configured, the page uses sample products and checkout is disabled. Do not accept real orders until sandbox payment notifications and stock updates are tested.

Because you're 14, have your parent/guardian own or supervise hosting, merchant/payment accounts, business details and legal/financial decisions. Never share passwords, merchant keys, or the Supabase service-role key.

## 1. Create Supabase
A parent/guardian should create a project and review current plan limits. In Supabase SQL Editor run `supabase/schema.sql`, then `supabase/fulfil_paid_order.sql`.

After signing up to the deployed store, have the guardian make only the owner account an admin:
```sql
update public.profiles set role='admin' where email='YOUR-OWNER-EMAIL';
```

## 2. Set frontend keys
In `index.html`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` with the project's Project URL and public anon key. Never put the service-role key in browser code.

## 3. Deploy Edge Functions
Install the Supabase CLI on a computer, log in and link the project:
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy create-payment
supabase functions deploy payfast-notify --no-verify-jwt
```
Set secrets (use sandbox credentials first):
```bash
supabase secrets set PAYFAST_MERCHANT_ID="YOUR_SANDBOX_MERCHANT_ID"
supabase secrets set PAYFAST_MERCHANT_KEY="YOUR_SANDBOX_MERCHANT_KEY"
supabase secrets set PAYFAST_PASSPHRASE="YOUR_SANDBOX_PASSPHRASE"
supabase secrets set PAYFAST_SANDBOX="true"
supabase secrets set SITE_URL="https://YOUR-PUBLISHED-SITE"
```
Supabase provides `SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions. Keep all secrets server-side.

## 4. Publish the website
Upload the root files (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`) to an HTTPS static host. A free hosting tier may work, but check current limits and terms. Add the final URL to `SITE_URL`.

## 5. Test before real orders
Use PayFast sandbox. Verify successful payment, cancellation, failed payment, wrong amounts, repeated notifications, insufficient stock and admin-only access. Confirm real supplier stock, product prices, delivery costs, refunds, contact details and privacy policy. The included photos and product entries are examples; replace them with products you can actually supply.

## 6. Android app
Once hosted over HTTPS, open the store URL in Chrome on the Android phone, open the menu and choose **Install app** or **Add to Home screen**. This installs the PWA-style app without a Play Store APK. Publishing a native app to an app store is a separate process.

## Current limitations to resolve before launch
- The included admin panel can add products and update order statuses; product editing, image upload, customer-facing order history, automatic email/SMS notifications, delivery-company integration and refund tooling need additional work.
- The product form uses image URLs; use licensed photos you own or have permission to use.
- Add a privacy policy and a clear returns/delivery policy before collecting real customer details.
- Payment providers may charge transaction fees; a free tool setup does not guarantee every part of operating the shop costs R0.
